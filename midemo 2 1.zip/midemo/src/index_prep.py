import pathlib
import argparse
from deltalake import DeltaTable

parser = argparse.ArgumentParser()
parser.add_argument('--data_input', dest="data_input", required=True)
parser.add_argument('--index_output', dest="index_output", required=True)
args, _ = parser.parse_known_args()

path = args.data_input
dt = DeltaTable(path)
print(dt.files())
print(dt.metadata().partition_columns)
index_dir = pathlib.Path(args.index_output)
index_dir.mkdir(exist_ok=True)
for item in dt.to_pandas(columns=dt.metadata().partition_columns).drop_duplicates().values:
    value = str(item[0])
    (index_dir / f"{value}.txt").write_text(value)
    print(value)