
import argparse
from deltalake import DeltaTable

def init():
    global deltalake_data
    #parse args for delta table initialization
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_input', dest="data_input", required=True)
    args, _ = parser.parse_known_args()
    deltalake_data = DeltaTable(args.data_input)


def run(input_data):
    # if we set mini-batch size as 1, we will get 1 file per mini-batch and each file contains a single partition
    print('We entered the run stage')
    for f in input_data:
        with open(f, 'r') as ff:
            # read month from file.
            line = ff.read()
            # load and filter by month
            pd = deltalake_data.to_pandas(partitions=[("month", "=", line)])
            # load delat table
            print(pd)
            print('We entered the run stage')
            ## rest of training code
    return []